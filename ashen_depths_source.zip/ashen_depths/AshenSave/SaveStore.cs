
using System;
using System.IO;
using System.Text;

namespace AshenSave;

/// <summary>Small managed DLL for atomic JSON save-file operations.</summary>
public static class SaveStore
{
    public static void Write(string path, string json)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(path);
        ArgumentNullException.ThrowIfNull(json);
        var fullPath = Path.GetFullPath(path);
        var directory = Path.GetDirectoryName(fullPath)!;
        Directory.CreateDirectory(directory);
        var temp = fullPath + ".writing";
        File.WriteAllText(temp, json, new UTF8Encoding(false));
        if (File.Exists(fullPath))
            File.Replace(temp, fullPath, fullPath + ".bak", true);
        else
            File.Move(temp, fullPath);
    }

    public static string Read(string path)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(path);
        return File.ReadAllText(Path.GetFullPath(path), Encoding.UTF8);
    }

    public static bool Exists(string path) => File.Exists(Path.GetFullPath(path));
}
