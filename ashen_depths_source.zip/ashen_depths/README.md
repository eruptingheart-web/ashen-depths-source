
# Ashen Depths

A source-first, asset-free terminal roguelike. Python owns gameplay; a C# class
library (`AshenSave.dll`) provides atomic JSON save-file writes and reads.
There are no downloaded art/audio assets and no browser runtime.

## Requirements
- Python 3.10+
- .NET 8 SDK (to build the save DLL)
- `pythonnet` (to load the DLL from Python)

## Build the DLL
From the project root:

```bash
dotnet build AshenSave/AshenSave.csproj -c Release
python -m pip install -r requirements.txt
python main.py
```

The DLL is generated at `AshenSave/bin/Release/net8.0/AshenSave.dll`.
On platforms where pythonnet/.NET loading is unavailable, the adapter uses
the same JSON format through Python's standard library. The C# DLL remains
the intended save backend when built and loadable.

## Play
- New expedition: create a fresh delver.
- Explore rooms, fight enemies, find caches, and use shrines.
- Combat offers strike, potion, and brace.
- Save from the exploration menu. Continue loads `saves/slot1.json`.
- Every floor is procedurally assembled; enemy stats scale with depth.

## Project layout
- `game/`: gameplay systems split by responsibility
- `data/`: editable JSON balance/content data
- `AshenSave/`: C# source for the save-system DLL
- `saves/`: generated player save files (not committed)

## Open source
No third-party game assets are included. You may fork, modify, and redistribute
the source under the license you choose. Add a license file before publishing
if you want to specify reuse terms.
