
def grant_xp(player, amount):
    player.xp += amount
    messages = []
    while player.xp >= player.level * 20:
        player.xp -= player.level * 20
        player.level += 1
        player.max_hp += 5
        player.hp = player.max_hp
        player.attack += 1
        messages.append(f"LEVEL UP: you are now level {player.level}.")
    return messages
