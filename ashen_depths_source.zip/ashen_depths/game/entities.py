
from dataclasses import dataclass, asdict

@dataclass
class Player:
    name: str = "Wanderer"
    hp: int = 30
    max_hp: int = 30
    attack: int = 6
    defense: int = 1
    potions: int = 2
    gold: int = 0
    floor: int = 1
    xp: int = 0
    level: int = 1
    weapon: str = "Rusty blade"

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, data):
        allowed = cls.__dataclass_fields__.keys()
        return cls(**{k: v for k, v in data.items() if k in allowed})

@dataclass
class Enemy:
    name: str
    hp: int
    attack: int
    defense: int
    xp: int
    gold: int
    behavior: str = "stalker"

    def alive(self):
        return self.hp > 0
