
import os

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def line():
    print("─" * 62)

def title():
    print(r"""
    ╔══════════════════════════════════════════════════════╗
    ║                    A S H E N   D E P T H S           ║
    ║             A procedural dungeon expedition         ║
    ╚══════════════════════════════════════════════════════╝
    """)

def status(player):
    print(f"{player.name}  |  Level {player.level}  |  Floor {player.floor}")
    print(f"HP {player.hp}/{player.max_hp}  |  ATK {player.attack} ({player.weapon})  |  DEF {player.defense}")
    print(f"XP {player.xp}/{player.level * 20}  |  Gold {player.gold}  |  Potions {player.potions}")
