
import random

WEAPONS = [
    ("Cracked cleaver", 2, 8), ("Grave-iron sword", 4, 16),
    ("Lantern pike", 3, 13), ("Blackglass edge", 6, 25)
]

def find_cache(player, floor):
    roll = random.random()
    if roll < .42:
        amount = random.randint(5, 12) + floor * 2
        player.gold += amount
        return f"You find {amount} gold."
    if roll < .78:
        player.potions += 1
        return "You find a sealed healing draught."
    name, bonus, price = random.choice(WEAPONS)
    if bonus > player.attack - 6:
        player.attack = 6 + bonus
        player.weapon = name
        return f"You equip {name}. Attack increased."
    player.gold += price // 2
    return f"You sell a spare {name} for {price // 2} gold."

def use_potion(player):
    if player.potions <= 0:
        return "You have no potions."
    if player.hp >= player.max_hp:
        return "You are already at full health."
    healed = min(14, player.max_hp - player.hp)
    player.hp += healed
    player.potions -= 1
    return f"The draught restores {healed} HP."
