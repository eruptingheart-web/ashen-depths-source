
import random

def player_strike(player, enemy):
    damage = max(1, player.attack + random.randint(-2, 2) - enemy.defense)
    enemy.hp -= damage
    return damage

def enemy_turn(player, enemy):
    # Behaviors alter risk rather than just changing enemy names.
    raw = enemy.attack + random.randint(-1, 2)
    if enemy.behavior == "ambusher":
        raw += 2
    elif enemy.behavior == "guard":
        raw = max(1, raw - 1)
    damage = max(1, raw - player.defense)
    player.hp -= damage
    return damage
