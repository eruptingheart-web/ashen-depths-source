
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
SAVE_DIR = ROOT / "saves"
SAVE_DIR.mkdir(exist_ok=True)

def read_json(name):
    with (DATA / name).open("r", encoding="utf-8") as f:
        return json.load(f)

SETTINGS = read_json("settings.json")
