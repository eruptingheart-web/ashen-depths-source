
"""Save adapter: uses the compiled C# DLL when pythonnet is installed.
The JSON fallback keeps the game usable on platforms without .NET/pythonnet.
"""
import json
from pathlib import Path
from .config import ROOT, SAVE_DIR

class SaveBridge:
    def __init__(self):
        self.dotnet = False
        dll = ROOT / "AshenSave" / "bin" / "Release" / "net8.0" / "AshenSave.dll"
        try:
            import clr
            if dll.exists():
                clr.AddReference(str(dll))
                from AshenSave import SaveStore
                self.store = SaveStore
                self.dotnet = True
        except Exception:
            self.dotnet = False

    def save(self, slot, payload):
        path = SAVE_DIR / f"{slot}.json"
        raw = json.dumps(payload, indent=2)
        if self.dotnet:
            self.store.Write(str(path), raw)
        else:
            path.write_text(raw, encoding="utf-8")

    def load(self, slot):
        path = SAVE_DIR / f"{slot}.json"
        if not path.exists():
            return None
        if self.dotnet:
            raw = self.store.Read(str(path))
        else:
            raw = path.read_text(encoding="utf-8")
        return json.loads(raw)

    def exists(self, slot):
        return (SAVE_DIR / f"{slot}.json").exists()
