
import random
from .entities import Player
from .dungeon import Dungeon
from .monsters import spawn_enemy
from .combat import player_strike, enemy_turn
from .items import find_cache, use_potion
from .progression import grant_xp
from .save_bridge import SaveBridge
from . import ui

class Game:
    def __init__(self):
        self.saves = SaveBridge()
        self.player = None
        self.dungeon = None
        self.running = True

    def run(self):
        random.seed()
        while self.running:
            ui.clear()
            ui.title()
            print("1) New expedition   2) Continue   3) Quit")
            choice = input("> ").strip()
            if choice == "1":
                name = input("Name your delver: ").strip() or "Wanderer"
                self.player = Player(name=name)
                self._new_floor()
                self.explore()
            elif choice == "2":
                self.continue_game()
            elif choice == "3":
                self.running = False
            else:
                input("Choose 1, 2, or 3. Enter to continue.")

    def _new_floor(self):
        self.dungeon = Dungeon(self.player.floor)

    def continue_game(self):
        try:
            data = self.saves.load("slot1")
            if not data:
                input("No save found. Enter to return.")
                return
            self.player = Player.from_dict(data["player"])
            self.dungeon = Dungeon(self.player.floor)
            self.dungeon.position = min(data.get("position", 0), len(self.dungeon.rooms)-1)
            self.explore()
        except Exception as exc:
            input(f"Save could not be loaded: {exc}. Enter to return.")

    def save_game(self):
        payload = {"version": 1, "player": self.player.to_dict(),
                   "position": self.dungeon.position}
        self.saves.save("slot1", payload)
        print("Expedition saved to saves/slot1.json.")

    def explore(self):
        while self.player and self.player.hp > 0:
            ui.clear()
            ui.title()
            ui.status(self.player)
            room = self.dungeon.current
            print(f"\nRoom {self.dungeon.position + 1}/{len(self.dungeon.rooms)}")
            print(room.description)
            if not room.cleared:
                self.resolve_room(room)
                room.cleared = True
                if self.player.hp <= 0:
                    break
            print("\n1) Continue  2) Use potion  3) Save  4) Return to title")
            choice = input("> ").strip()
            if choice == "1":
                if self.dungeon.position == len(self.dungeon.rooms) - 1:
                    self.player.floor += 1
                    self.player.hp = min(self.player.max_hp, self.player.hp + 5)
                    self._new_floor()
                    print("You descend. The cold grows heavier.")
                    input("Enter to continue.")
                else:
                    self.dungeon.advance()
            elif choice == "2":
                print(use_potion(self.player))
                input("Enter to continue.")
            elif choice == "3":
                self.save_game()
                input("Enter to continue.")
            elif choice == "4":
                return
        if self.player and self.player.hp <= 0:
            ui.clear()
            print("YOUR LIGHT GOES OUT")
            print(f"You reached floor {self.player.floor}, level {self.player.level}.")
            print("The expedition is over. Start a new run to try again.")
            input("Enter to return to title.")

    def resolve_room(self, room):
        if room.kind in ("battle", "elite"):
            enemy = spawn_enemy(self.player.floor, room.kind == "elite")
            print(f"\nA {enemy.name} emerges! ({enemy.hp} HP)")
            while enemy.alive() and self.player.hp > 0:
                print(f"\nYou: {self.player.hp} HP | {enemy.name}: {max(0, enemy.hp)} HP")
                print("1) Strike  2) Drink potion  3) Brace")
                choice = input("> ").strip()
                if choice == "2":
                    print(use_potion(self.player))
                    continue
                if choice == "3":
                    old = self.player.defense
                    self.player.defense += 3
                    damage = enemy_turn(self.player, enemy)
                    self.player.defense = old
                    print(f"You brace; the blow deals {damage} damage.")
                    continue
                damage = player_strike(self.player, enemy)
                print(f"You hit for {damage}.")
                if enemy.alive():
                    damage = enemy_turn(self.player, enemy)
                    print(f"{enemy.name} hits you for {damage}.")
            if self.player.hp > 0:
                self.player.gold += enemy.gold
                print(f"{enemy.name} falls. +{enemy.xp} XP, +{enemy.gold} gold.")
                for message in grant_xp(self.player, enemy.xp):
                    print(message)
                input("Enter to continue.")
        elif room.kind == "cache":
            print(find_cache(self.player, self.player.floor))
            input("Enter to continue.")
        elif room.kind == "shrine":
            if random.random() < .65:
                self.player.max_hp += 2
                self.player.hp = min(self.player.max_hp, self.player.hp + 8)
                print("The shrine warms your bones. Max HP +2; HP restored.")
            else:
                self.player.attack += 1
                print("A red spark enters your weapon. Attack +1.")
            input("Enter to continue.")
        else:
            print("You catch your breath. 3 HP restored.")
            self.player.hp = min(self.player.max_hp, self.player.hp + 3)
            input("Enter to continue.")
