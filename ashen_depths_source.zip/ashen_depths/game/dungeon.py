
import random
from dataclasses import dataclass

@dataclass
class Room:
    kind: str
    description: str
    cleared: bool = False

class Dungeon:
    ROOM_TYPES = ["battle", "cache", "shrine", "quiet", "battle", "elite"]

    def __init__(self, floor, room_count=7):
        self.floor = floor
        self.rooms = self._generate(room_count)
        self.position = 0

    def _generate(self, count):
        rooms = []
        for i in range(count):
            kind = random.choice(self.ROOM_TYPES)
            if i == 0:
                kind = "quiet"
            if i == count - 1:
                kind = "exit"
            descriptions = {
                "battle": "A scrape of claws echoes from the dark.",
                "cache": "A half-buried supply chest rests against the wall.",
                "shrine": "A cold stone shrine hums beneath the dust.",
                "quiet": "The corridor is still. For now.",
                "elite": "A hulking silhouette blocks the passage.",
                "exit": "A stairwell descends into deeper darkness."
            }
            rooms.append(Room(kind, descriptions[kind]))
        return rooms

    @property
    def current(self):
        return self.rooms[self.position]

    def advance(self):
        if self.position < len(self.rooms) - 1:
            self.position += 1
            return self.current
        return None
