
import random
from .entities import Enemy
from .config import read_json

MONSTERS = read_json("enemies.json")

def spawn_enemy(floor, elite=False):
    pool = [m for m in MONSTERS if (m["tier"] <= floor + 1)]
    if elite:
        pool = [m for m in pool if m["tier"] >= 2] or pool
    template = random.choice(pool)
    scale = max(0, floor - 1)
    return Enemy(
        template["name"], template["hp"] + scale * 3,
        template["attack"] + scale, template["defense"],
        template["xp"] + scale * 2, template["gold"] + scale * 2,
        template["behavior"]
    )
